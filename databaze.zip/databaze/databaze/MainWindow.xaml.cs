﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace databaze
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<Auto> SeznamAut { get; set; }

        public MainWindow()
        {
            InitializeComponent();


            SeznamAut = new ObservableCollection<Auto>();


            dgAuta.ItemsSource = SeznamAut;
        }


        private void BtnPridat_Click(object sender, RoutedEventArgs e)
        {

            if (string.IsNullOrWhiteSpace(txtZnacka.Text) || string.IsNullOrWhiteSpace(txtModel.Text))
            {
                MessageBox.Show("Zadej aspoň značku a model!", "Chyba", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }


            Auto nove = new Auto
            {
                Id = SeznamAut.Count + 1,
                Znacka = txtZnacka.Text,
                ModelAuta = txtModel.Text,
                Karoserie = txtKaroserie.Text,
                Mam = chkGaraz.IsChecked ?? false
            };


            int.TryParse(txtRok.Text, out int rok);
            nove.RokVyroby = rok;
            int.TryParse(txtVykon.Text, out int vykon);
            nove.VykonKw = vykon;


            SeznamAut.Add(nove);
            VycistitPole();
        }


        private void BtnSmazat_Click(object sender, RoutedEventArgs e)
        {
         
            if (dgAuta.SelectedItem is Auto vybrane)
            {
                var vysledek = MessageBox.Show($"Opravdu chceš smazat {vybrane.Znacka} {vybrane.ModelAuta}?", "Potvrzení", MessageBoxButton.YesNo);
                if (vysledek == MessageBoxResult.Yes)
                {
                    SeznamAut.Remove(vybrane);
                }
            }
            else
            {
                MessageBox.Show("Nejdřív vyber auto v tabulce!");
            }
        }

        private void BtnVycistit_Click(object sender, RoutedEventArgs e)
        {
            VycistitPole();
        }

        private void VycistitPole()
        {
            txtZnacka.Clear();
            txtModel.Clear();
            txtRok.Clear();
            txtKaroserie.Clear();
            txtVykon.Clear();
            chkGaraz.IsChecked = false;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
        
   
        }
       
        }
    

    